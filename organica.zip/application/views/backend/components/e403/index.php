<div class="content-wrapper">
    <section class="content">
    	<div class="full-screen" style="min-height: 549px; background: #fff">
			<div class="center" style="padding-top: 5%">
				<h3 class="text-center" style="color: red">Rất tiếc, trang bạn tìm không tồn tại !</h3>
				<p class="pull-left" style="padding-left: 20px;">Nhấn vào <a href="<?php echo base_url() ?>admin">đây</a> để ở về trang chủ !!</p>
			</div>
		</div>
    </section>
</div>