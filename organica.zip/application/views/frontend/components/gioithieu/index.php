<center><h3>• Website đồ án tốt nghiệp được chạy trên nền tảng host ảo localhost	<br/>
  "Công ty CP Đầu tư Organica - Phát triển và phân phối thực phẩm hữu cơ cho người Việt" được thiết kế theo tiêu chi dễ 	<br/>
 nhìn thân thiện với người dùng
	<br/>
• Được thực hiện bởi sinh viên:
	<br/>
○ Đặng Văn Hưng
	<br/>
○ Lê Văn Anh Dũng
	<br/>
• Trường Cao đẳng nghề Đà Nẵng</h3></center>